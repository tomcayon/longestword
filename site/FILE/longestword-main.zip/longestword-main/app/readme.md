# The Longest Word App

Here's the app package. You can launch the app by running `main.py`.
**Make sure this is the current work directory**, or the module importation will be broken. If you're using pyzo, you have to check this option on the `RUN`sub-menu.

Once you've finished the party, juste close the window.
