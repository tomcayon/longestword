"""

Main.py

"""

import core_module

app = core_module.AppCore()
app.launch_app()